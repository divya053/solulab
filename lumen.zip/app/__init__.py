"""Christianity-focused AI assistant — grounded, safe, denomination-aware."""
__version__ = "0.1.0"
