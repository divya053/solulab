"""LLM provider interface.

The pipeline depends only on this interface, so the actual model (Anthropic,
OpenAI, a local model, or the offline grounded responder) is swappable via
configuration. `GenerationRequest` carries everything a provider needs; the
pipeline assembles it the same way regardless of backend.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass, field


@dataclass
class GenerationRequest:
    system: str
    # chat history as {"role": "user"|"assistant", "content": str}
    messages: list[dict]
    # retrieved grounding context (already formatted) for offline/templated use
    context_block: str = ""
    grounding_verses: list[dict] = field(default_factory=list)
    grounding_kb: list[dict] = field(default_factory=list)
    extra_guidance: str = ""
    max_tokens: int = 900
    temperature: float = 0.4


class LLMProvider(abc.ABC):
    name: str = "base"

    @abc.abstractmethod
    def generate(self, req: GenerationRequest) -> str:
        ...

    @property
    def is_grounded_offline(self) -> bool:
        """True for providers that build answers directly from retrieved context."""
        return False
