"""Deterministic, grounded offline responder.

Why this exists
---------------
The demo must run with *zero API keys*. Rather than a dead "configure a key"
stub, this provider produces a genuinely useful, grounded answer by composing
the retrieved scripture + knowledge-base context into a pastoral reply.

It deliberately *only* states what the retrieved context supports and *only*
quotes verses that came from the verified store — so it cannot hallucinate
scripture by construction. It is intentionally conservative: when it has no
grounding it says so instead of guessing. When an API key is configured, the
LLM providers take over and this becomes the safety net / fallback.
"""
from __future__ import annotations

import re

from .base import GenerationRequest, LLMProvider


def _last_user(messages: list[dict]) -> str:
    for m in reversed(messages):
        if m["role"] == "user":
            return m["content"]
    return ""


def _wants_prayer(text: str) -> bool:
    return bool(re.search(r"\b(pray(er)?|intercede|bless(ing)?)\b", text, re.IGNORECASE))


def _wants_content(text: str) -> bool:
    return bool(re.search(r"\b(write|compose|devotional|reflection|poem|meditation|sermon|essay)\b",
                          text, re.IGNORECASE))


class OfflineProvider(LLMProvider):
    name = "offline-grounded"

    @property
    def is_grounded_offline(self) -> bool:
        return True

    def generate(self, req: GenerationRequest) -> str:
        question = _last_user(req.messages)
        verses = req.grounding_verses
        kb = req.grounding_kb

        parts: list[str] = []

        if kb:
            parts.append(kb[0]["text"])
            if len(kb) > 1:
                parts.append(kb[1]["text"])

        if req.extra_guidance:
            parts.append(
                "Faithful Christians have held more than one view on this, so here it "
                "matters to hold the question gently and represent the traditions fairly."
            )

        if verses:
            lead = "Scripture speaks to this. " if not kb else "Scripture that bears on this includes: "
            parts.append(lead)
            for v in verses[:3]:
                parts.append(f"• {v['reference']} — \"{v['text']}\"")

        if _wants_prayer(question):
            anchor = verses[0]["reference"] if verses else "Psalm 23:1"
            parts.append(
                "\nA short prayer: Heavenly Father, thank You for Your steadfast love. "
                "Meet us in this moment, give us wisdom and peace, and help us to trust "
                f"You as Your Word reminds us in {anchor}. In Jesus' name, Amen."
            )
        elif _wants_content(question):
            if verses:
                v = verses[0]
                parts.append(
                    f"\nA brief reflection: In {v['reference']} we read, \"{v['text']}\" "
                    "Let these words settle in today — God's promises are sure, and we are "
                    "invited to rest in them rather than in our own striving."
                )

        if not parts:
            parts.append(
                "I want to answer carefully and only from what I can ground in scripture "
                "and vetted sources. I don't have enough grounded material on hand to "
                "answer this confidently without risking inaccuracy. Could you rephrase or "
                "narrow the question? I'm strongest on scripture, theology, church "
                "history, prayer, and Christian living."
            )

        parts.append(
            "\n_(Offline grounded mode: this reply is composed only from verified KJV "
            "scripture and a vetted knowledge base. Configure an API key for richer, "
            "free-form responses — all still passed through the same scripture verifier "
            "and safety checks.)_"
        )
        return "\n".join(parts)
