"""Selects an LLM provider based on environment configuration.

Priority: explicit LLM_PROVIDER env > whichever API key is present > offline.
The offline grounded responder is always the fallback so the app never hard-fails
due to missing credentials.
"""
from __future__ import annotations

import os

from .base import LLMProvider
from .offline_provider import OfflineProvider


def build_provider() -> LLMProvider:
    choice = os.environ.get("LLM_PROVIDER", "").strip().lower()
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    openai_key = os.environ.get("OPENAI_API_KEY", "").strip()

    if choice == "offline":
        return OfflineProvider()
    if choice == "anthropic" or (not choice and anthropic_key):
        if anthropic_key:
            from .anthropic_provider import AnthropicProvider
            return AnthropicProvider(anthropic_key)
    if choice == "openai" or (not choice and openai_key):
        if openai_key:
            from .openai_provider import OpenAIProvider
            return OpenAIProvider(openai_key)
    return OfflineProvider()
