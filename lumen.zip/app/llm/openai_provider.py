"""OpenAI provider (used when OPENAI_API_KEY is set).

Same contract as the Anthropic provider; lazy SDK import so it's optional.
"""
from __future__ import annotations

import os

from .base import GenerationRequest, LLMProvider

DEFAULT_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")


class OpenAIProvider(LLMProvider):
    name = "openai"

    def __init__(self, api_key: str, model: str = DEFAULT_MODEL):
        self.api_key = api_key
        self.model = model

    def generate(self, req: GenerationRequest) -> str:
        from openai import OpenAI  # lazy import

        client = OpenAI(api_key=self.api_key)
        system = req.system
        if req.context_block:
            system += (
                "\n\n# Grounding context (authoritative - prefer it over memory)\n"
                + req.context_block
                + "\n\nOnly quote Bible verses that appear above or that you are certain of; "
                "every citation will be checked against a KJV database after you answer."
            )
        if req.extra_guidance:
            system += "\n\n# Special handling\n" + req.extra_guidance

        messages = [{"role": "system", "content": system}]
        messages.extend({"role": m["role"], "content": m["content"]} for m in req.messages)

        resp = client.chat.completions.create(
            model=self.model,
            max_tokens=req.max_tokens,
            temperature=req.temperature,
            messages=messages,
        )
        return resp.choices[0].message.content or ""
