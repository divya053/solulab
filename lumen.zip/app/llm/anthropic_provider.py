"""Anthropic Claude provider (used when ANTHROPIC_API_KEY is set).

Kept import-light: the SDK is only imported lazily so the app runs without the
package installed. The system prompt + grounding context are assembled by the
pipeline; this class just performs the call.
"""
from __future__ import annotations

import os

from .base import GenerationRequest, LLMProvider

DEFAULT_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-6")


class AnthropicProvider(LLMProvider):
    name = "anthropic"

    def __init__(self, api_key: str, model: str = DEFAULT_MODEL):
        self.api_key = api_key
        self.model = model

    def generate(self, req: GenerationRequest) -> str:
        from anthropic import Anthropic  # lazy import

        client = Anthropic(api_key=self.api_key)
        system = req.system
        if req.context_block:
            system += (
                "\n\n# Grounding context (authoritative - prefer it over memory)\n"
                + req.context_block
                + "\n\nOnly quote Bible verses that appear above or that you are certain of; "
                "every citation will be checked against a KJV database after you answer."
            )
        if req.extra_guidance:
            system += "\n\n# Special handling\n" + req.extra_guidance

        resp = client.messages.create(
            model=self.model,
            max_tokens=req.max_tokens,
            temperature=req.temperature,
            system=system,
            messages=[{"role": m["role"], "content": m["content"]} for m in req.messages],
        )
        return "".join(block.text for block in resp.content if block.type == "text")
