"""Denomination-aware handling.

The assistant supports a denominational "lens". When set, it shapes:
  * which authorities/emphases the answer foregrounds,
  * the canon used for scripture lookups (Catholic/Orthodox include deuterocanon
    — flagged here even though our bundled KJV text is Protestant, so the system
    is honest about that limitation),
  * tone.

Crucially, the default is ECUMENICAL: lead with the shared historic consensus
(Apostles'/Nicene Creed) and then note where traditions differ — rather than
silently picking sides.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Denomination:
    key: str
    label: str
    emphasis: str
    authorities: str
    notes: str = ""
    deuterocanon: bool = False


DENOMINATIONS: dict[str, Denomination] = {
    "ecumenical": Denomination(
        key="ecumenical",
        label="Ecumenical (default)",
        emphasis=(
            "Lead with the historic consensus shared across Christianity (the "
            "Nicene/Apostles' Creed: Trinity, incarnation, death and resurrection "
            "of Christ, salvation by grace). Then fairly note where traditions differ."
        ),
        authorities="Scripture and the ecumenical creeds; represent multiple traditions fairly.",
    ),
    "catholic": Denomination(
        key="catholic",
        label="Roman Catholic",
        emphasis=(
            "Foreground Scripture *and* Sacred Tradition, the Magisterium, the seven "
            "sacraments, the communion of saints, and Marian doctrine where relevant."
        ),
        authorities="Scripture, Sacred Tradition, the Catechism of the Catholic Church, the Magisterium.",
        deuterocanon=True,
        notes="Catholic canon includes the deuterocanonical books (e.g. Sirach, Wisdom, Tobit).",
    ),
    "orthodox": Denomination(
        key="orthodox",
        label="Eastern Orthodox",
        emphasis=(
            "Foreground Holy Tradition, the seven Ecumenical Councils, theosis, the "
            "Church Fathers, and the liturgical/sacramental life."
        ),
        authorities="Scripture, Holy Tradition, the Ecumenical Councils, the Church Fathers.",
        deuterocanon=True,
        notes="Orthodox canon includes the anagignoskomena (deuterocanonical books).",
    ),
    "protestant": Denomination(
        key="protestant",
        label="Protestant (general)",
        emphasis=(
            "Foreground sola scriptura, justification by faith, the priesthood of all "
            "believers, and the centrality of the biblical text."
        ),
        authorities="Scripture as the final authority (sola scriptura); the Reformation confessions.",
    ),
}

DEFAULT = "ecumenical"


def get_denomination(key: str | None) -> Denomination:
    if not key:
        return DENOMINATIONS[DEFAULT]
    return DENOMINATIONS.get(key.lower().strip(), DENOMINATIONS[DEFAULT])


def list_denominations() -> list[dict]:
    return [{"key": d.key, "label": d.label} for d in DENOMINATIONS.values()]
