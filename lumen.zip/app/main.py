"""FastAPI application: chat, scripture lookup/search, and image generation.

Static UI is served from app/static. All heavy objects (corpus, retriever,
pipeline) are singletons built lazily on first use.
"""
from __future__ import annotations

import os

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .config import runtime_info
from .denomination.profiles import list_denominations
from .image.generator import ImageGenerator
from .pipeline import get_pipeline
from .scripture.canon import Reference, extract_references, normalize_book
from .scripture.store import get_store
from .schemas import (
    ChatRequest,
    ChatResponse,
    ImageRequest,
    ImageResponse,
    SearchResponse,
    VerseLookupResponse,
)

app = FastAPI(title="Christianity AI Assistant", version="0.1.0")

STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")
_image_gen = ImageGenerator()


@app.get("/api/health")
def health():
    return {"status": "ok", **runtime_info()}


@app.get("/api/denominations")
def denominations():
    return {"denominations": list_denominations()}


@app.post("/api/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    result = get_pipeline().chat(req.session_id, req.message, req.denomination)
    return ChatResponse(
        reply=result.reply,
        blocked=result.blocked,
        denomination=result.denomination,
        trace=result.trace.__dict__,
    )


@app.get("/api/verse", response_model=VerseLookupResponse)
def verse(ref: str):
    """Look up a single reference and return verified KJV text (or why it's invalid)."""
    store = get_store()
    refs = extract_references(ref, store.book_names)
    if not refs:
        token = ref.split()[0] if ref.split() else ref
        if normalize_book(token, store.book_names) is None:
            return VerseLookupResponse(reference=ref, found=False,
                                       message="Unrecognized book or reference format.")
        return VerseLookupResponse(reference=ref, found=False,
                                   message="Could not parse a chapter/verse reference.")
    r: Reference = refs[0]
    if not store.reference_in_bounds(r):
        return VerseLookupResponse(reference=str(r), found=False,
                                   message=f"{r} is outside the canonical bounds.")
    return VerseLookupResponse(reference=str(r), found=True, text=store.get_passage(r))


@app.get("/api/search", response_model=SearchResponse)
def search(q: str, k: int = 5):
    store = get_store()
    return SearchResponse(query=q, results=store.search(q, top_k=k))


@app.post("/api/image", response_model=ImageResponse)
def image(req: ImageRequest):
    result = _image_gen.generate(req.prompt)
    return ImageResponse(
        ok=result.ok, provider=result.provider, final_prompt=result.final_prompt,
        image_url=result.image_url, image_svg=result.image_svg, note=result.note,
        refused_reason=result.refused_reason, safety=result.safety,
    )


@app.get("/")
def index():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))


# Mount static assets (after routes so "/" hits the handler above).
if os.path.isdir(STATIC_DIR):
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
