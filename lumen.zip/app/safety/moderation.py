"""Input/output moderation for the assistant.

Design notes
------------
* Rule-based + lexical detection chosen deliberately: it is transparent,
  deterministic, testable, and runs offline. In production you'd layer a
  hosted moderation model (OpenAI/Anthropic/Perspective) *in addition* — the
  `external_hook` seam is left for exactly that.
* Two passes:
    - `screen_input`  : decide whether to even call the model.
    - `screen_output` : last-mile check on generated text before it reaches
      the user (catches the model being talked into something).
* We bias toward SAFE_COMPLETE / REDIRECT over hard refusal for *legitimate*
  hard questions (suffering, hell, other religions, denominational disputes),
  because refusing those would make the product useless and pastorally cold.
  Hard refusal is reserved for genuinely harmful intent.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable, Optional

from .policies import RESPONSES, Action, Category, PolicyHit


def _any(text: str, patterns: list[str]) -> Optional[str]:
    for p in patterns:
        m = re.search(p, text, re.IGNORECASE)
        if m:
            return m.group(0)
    return None


# --- pattern banks -----------------------------------------------------------
# Manipulation verbs we never apply to scripture.
_MANIP = r"\b(rewrite|re-write|change|alter|edit|modify|twist|distort|reword|fake|forge|make up|invent|fabricate)"
SCRIPTURE_MANIPULATION = [
    # verb near an explicit scripture keyword
    _MANIP + r"\b[^.?!]{0,40}\b(verse|scripture|bible|passage|gospel|psalm|proverb|commandment|book of \w+)\b",
    # explicit scripture keyword bent toward an agenda
    r"\b(verse|scripture|bible|passage|gospel)\b[^.?!]{0,40}\b(to (support|justify|prove|endorse|condemn|promote)|that says)\b",
    r"\b(invent|fabricate|make up)\b[^.?!]{0,30}\b(verse|citation|reference|quote)\b",
    # intent-based: a manipulation verb steered toward an agenda, even when the
    # target is named only by a book (e.g. "twist Leviticus to justify ...",
    # "rewrite John 3:16 to support ...") — catches the flagship adversarial case.
    _MANIP + r"\b[^.?!]{0,45}\b(to (support|justify|prove|endorse|condemn|promote|attack)|so (it|that|they))\b",
]

VIOLENCE_EXTREMISM = [
    r"\b(kill|attack|harm|destroy|exterminate|cleanse|crusade against|wage (holy )?war on)\b[^.?!]{0,40}\b(jews|muslims|gays|infidels|heretics|unbelievers|non-?christians|them|people)\b",
    r"\bgod (wants|commands|tells|told) (me|us) to (kill|hurt|attack|punish)\b",
    r"\b(justify|justification for) (violence|killing|genocide)\b",
]

HATE_RELIGIOUS = [
    r"\b(jews|muslims|hindus|atheists|gays|catholics|protestants|christians|immigrants)\b[^.?!]{0,30}\b(are (evil|subhuman|vermin|animals|demons)|should be (hated|removed|punished))\b",
    r"\bwrite (a )?(sermon|post|essay|rant)\b[^.?!]{0,40}\b(hate|against|condemn(ing)?)\b[^.?!]{0,40}\b(jews|muslims|gays|lgbt|immigrants|women)\b",
    r"\bprove\b[^.?!]{0,45}\b(race|people|group|ethnicity|nation|gender)\b[^.?!]{0,25}\b(inferior|cursed|evil|subhuman|damned)\b",
]

SELF_HARM = [
    r"\b(kill myself|end my life|suicid(e|al)|hurt myself|self[- ]harm|want to die|don'?t want to (live|be alive))\b",
    r"\b(better off dead|no reason to live)\b",
]

ADVERSARIAL = [
    r"\b(ignore|disregard|forget|override)\b[^.?!]{0,30}\b(previous|prior|above|earlier|all)\b[^.?!]{0,20}\b(instructions?|prompts?|rules?|guidelines?)\b",
    r"\b(you are now|act as|pretend to be|roleplay as|from now on you (are|will))\b[^.?!]{0,40}\b(dan|unfiltered|jailbroken|no (rules|restrictions|filter|guardrails))\b",
    r"\b(developer mode|jailbreak|bypass (your )?(safety|guardrails|filters?))\b",
    r"\b(reveal|print|show|repeat)\b[^.?!]{0,20}\b(system prompt|your (instructions|prompt|rules))\b",
]

# Heresy / divisive-doctrine cues: legitimate to discuss, must not be asserted
# as settled orthodox fact. We steer these to SAFE_COMPLETE.
SENSITIVE_THEOLOGY = [
    r"\b(predestination|free will|trinity|hell|eternal (torment|punishment)|annihilation|purgatory|universalism|salvation by (faith|works)|once saved|speaking in tongues|infant baptism|transubstantiation|real presence|papal|sola scriptura|prosperity gospel|calvinis|arminian)\b",
    r"\b(why does god allow|problem of (evil|suffering)|why do (good people|the righteous) suffer)\b",
    r"\b(is (\w+ )?going to hell|are (catholics|protestants|mormons|muslims)( real| true)? (saved|christians))\b",
    r"\b(real christians|false religion|true religion)\b",
]

HERESY_AS_FACT = [
    r"\b(confirm|prove|tell me (it'?s|that it is) true|assert|state as fact)\b[^.?!]{0,45}\b(jesus (was|is) (not|just a)|god (is not|does not exist)|trinity is false|bible is (fake|fiction|a myth|myth))\b",
]


@dataclass
class ModerationResult:
    action: Action
    hits: list[PolicyHit] = field(default_factory=list)
    response: Optional[str] = None     # safe canned text when action != ALLOW/SAFE_COMPLETE
    guidance: Optional[str] = None     # extra instruction injected into the model prompt

    @property
    def blocked(self) -> bool:
        return self.action in (Action.REFUSE, Action.REDIRECT)


class Moderator:
    def __init__(self, external_hook: Optional[Callable[[str], Optional[PolicyHit]]] = None):
        # external_hook lets you plug a hosted moderation model in production.
        self.external_hook = external_hook

    # -- input ---------------------------------------------------------------
    def screen_input(self, text: str) -> ModerationResult:
        if m := _any(text, SELF_HARM):
            hit = PolicyHit(Category.SELF_HARM, Action.REFUSE,
                            "possible self-harm / crisis content", m)
            return ModerationResult(Action.REFUSE, [hit], RESPONSES[Category.SELF_HARM])

        if m := _any(text, VIOLENCE_EXTREMISM):
            hit = PolicyHit(Category.VIOLENCE_EXTREMISM, Action.REFUSE,
                            "religiously-framed violence/extremism", m)
            return ModerationResult(Action.REFUSE, [hit], RESPONSES[Category.VIOLENCE_EXTREMISM])

        if m := _any(text, HATE_RELIGIOUS):
            hit = PolicyHit(Category.HATE_RELIGIOUS, Action.REFUSE,
                            "hateful content targeting a group", m)
            return ModerationResult(Action.REFUSE, [hit], RESPONSES[Category.HATE_RELIGIOUS])

        if m := _any(text, SCRIPTURE_MANIPULATION):
            hit = PolicyHit(Category.SCRIPTURE_MANIPULATION, Action.REFUSE,
                            "request to alter/fabricate scripture", m)
            return ModerationResult(Action.REFUSE, [hit], RESPONSES[Category.SCRIPTURE_MANIPULATION])

        if m := _any(text, ADVERSARIAL):
            hit = PolicyHit(Category.ADVERSARIAL_INJECTION, Action.REFUSE,
                            "prompt-injection / jailbreak attempt", m)
            return ModerationResult(Action.REFUSE, [hit], RESPONSES[Category.ADVERSARIAL_INJECTION])

        if external := (self.external_hook(text) if self.external_hook else None):
            return ModerationResult(Action.REFUSE, [external],
                                    RESPONSES.get(external.category, RESPONSES[Category.OFF_DOMAIN]))

        # Asking us to assert a heresy as settled biblical fact: don't refuse
        # outright (it's discussable), but steer to a careful, non-dogmatic framing.
        if m := _any(text, HERESY_AS_FACT):
            hit = PolicyHit(Category.HERESY_AS_FACT, Action.SAFE_COMPLETE,
                            "request to assert non-orthodox claim as settled fact", m)
            guidance = (
                "The user wants a contested or non-orthodox claim affirmed as settled "
                "biblical fact. Don't assert it as such. Explain what the text actually "
                "says and where this claim sits relative to historic Christian orthodoxy, "
                "fairly and without hostility."
            )
            return ModerationResult(Action.SAFE_COMPLETE, [hit], guidance=guidance)

        # Legitimate-but-sensitive: allow, but steer the model to be careful,
        # balanced, and non-dogmatic. This is what makes hard questions land well.
        if m := _any(text, SENSITIVE_THEOLOGY):
            hit = PolicyHit(Category.SENSITIVE_THEOLOGY, Action.SAFE_COMPLETE,
                            "divisive/difficult theological topic", m)
            guidance = (
                "This is a difficult or denominationally divisive topic. Present the "
                "major Christian perspectives fairly (cite the relevant traditions), "
                "distinguish core consensus from disputed interpretation, stay pastoral "
                "and humble, and avoid declaring one side the only valid Christian view."
            )
            return ModerationResult(Action.SAFE_COMPLETE, [hit], guidance=guidance)

        return ModerationResult(Action.ALLOW, [])

    # -- output --------------------------------------------------------------
    def screen_output(self, text: str) -> ModerationResult:
        """Last-mile check on generated text."""
        for bank, cat in (
            (VIOLENCE_EXTREMISM, Category.VIOLENCE_EXTREMISM),
            (HATE_RELIGIOUS, Category.HATE_RELIGIOUS),
        ):
            if m := _any(text, bank):
                hit = PolicyHit(cat, Action.REFUSE, "unsafe content in model output", m)
                return ModerationResult(Action.REFUSE, [hit], RESPONSES[cat])
        return ModerationResult(Action.ALLOW)
