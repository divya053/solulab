"""Policy definitions for the moderation layer.

These are intentionally explicit and data-driven so reviewers can see exactly
what the assistant refuses, and so categories can be tuned without touching the
detection logic.  This is a *defense-in-depth* layer: it runs on both input and
output, and is complemented by the LLM's own system-prompt guardrails.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Action(str, Enum):
    ALLOW = "allow"
    REFUSE = "refuse"          # block outright, return a safe refusal
    SAFE_COMPLETE = "safe_complete"  # answer, but steer to a careful framing
    REDIRECT = "redirect"      # off-domain; gently redirect to the app's purpose


class Category(str, Enum):
    HATE_RELIGIOUS = "hate_religious"        # using faith to demean/attack a group
    VIOLENCE_EXTREMISM = "violence_extremism"  # religiously-justified violence
    SELF_HARM = "self_harm"
    SCRIPTURE_MANIPULATION = "scripture_manipulation"  # "rewrite verse to support X"
    HERESY_AS_FACT = "heresy_as_fact"        # asking us to assert heresy as orthodox truth
    ADVERSARIAL_INJECTION = "adversarial_injection"  # prompt-injection / jailbreak
    OFF_DOMAIN = "off_domain"
    SENSITIVE_THEOLOGY = "sensitive_theology"  # divisive but legitimate Q -> careful


@dataclass
class PolicyHit:
    category: Category
    action: Action
    reason: str
    matched: str = ""


# Canned, pastoral refusal/redirect messages keyed by category.
RESPONSES = {
    Category.HATE_RELIGIOUS: (
        "I can't help create content that demeans or attacks people of any faith, "
        "background, or group. The heart of the Christian message is love of God and "
        "love of neighbour (Matthew 22:37-39). If you'd like, I can share what the "
        "Bible teaches about loving others — including those we disagree with."
    ),
    Category.VIOLENCE_EXTREMISM: (
        "I won't produce content that promotes or justifies violence, even when it's "
        "framed in religious terms. Jesus taught, “Blessed are the peacemakers” "
        "(Matthew 5:9). I'm glad to discuss peace, justice, or how Christians have "
        "wrestled with these questions throughout history."
    ),
    Category.SELF_HARM: (
        "I'm really sorry you're carrying this. I'm not able to be a substitute for "
        "real help, and I want you to be safe. Please reach out to a local crisis line "
        "or someone you trust right now. You are deeply loved — “The LORD is nigh unto "
        "them that are of a broken heart” (Psalm 34:18). If it helps, I can also share "
        "passages of comfort or a prayer."
    ),
    Category.SCRIPTURE_MANIPULATION: (
        "I can't rewrite or alter Bible verses to make them appear to support a "
        "particular agenda — that would misrepresent the text. What I can do is quote "
        "the passage accurately and explain how different Christian traditions have "
        "interpreted it. Would that help?"
    ),
    Category.HERESY_AS_FACT: (
        "I can explain that teaching and where it sits relative to historic Christian "
        "orthodoxy, but I won't present it as the Bible's settled teaching when it "
        "isn't. Let me lay out what the major traditions actually hold."
    ),
    Category.ADVERSARIAL_INJECTION: (
        "I'll stick to my purpose here: I'm a Christianity-focused assistant grounded "
        "in scripture, and I keep my safety and accuracy guidelines in place. How can "
        "I help you with a faith-related question?"
    ),
    Category.OFF_DOMAIN: (
        "I'm focused on Christianity — scripture, theology, church history, prayer, and "
        "Christian living. I'm not the best tool for that question, but I'd be glad to "
        "help with anything in that space."
    ),
}
