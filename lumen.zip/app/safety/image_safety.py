"""Safety checks specific to the Christian image-generation flow.

Two concerns:
1. Block image prompts that are hateful, violent, sexual, or that target a group
   under religious cover ("subtly violate policies").
2. Respect a common, *legitimate* religious sensitivity: many traditions avoid
   visual depictions of God the Father / the divine being, and depictions of the
   Prophet Muhammad are deeply offensive to Muslims. We don't hard-block faces of
   Jesus (a long Christian artistic tradition), but we flag/reframe requests that
   are likely to cause offense and steer toward symbolic representation.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional


@dataclass
class ImageSafetyResult:
    allowed: bool
    reason: str = ""
    revised_prompt: Optional[str] = None   # safer reframing when applicable
    note: Optional[str] = None             # user-facing note about a reframing


_BLOCK = [
    (r"\b(nude|naked|nsfw|sexual|erotic|porn)\b", "sexual content"),
    (r"\b(gore|bloody|mutilat|behead|corpse|dead body)\b", "graphic violence"),
    (r"\b(kill|attack|slaughter|burn(ing)?|destroy|bomb)\b[^.?!]{0,30}\b(mosque|synagogue|temple|muslims|jews|gays|church)\b",
     "violence targeting a group or place of worship"),
    (r"\b(mock|ridicul|insult|degrad|blasphem)\b[^.?!]{0,30}\b(jesus|christ|god|muhammad|prophet|allah|virgin mary|saints?)\b",
     "content that mocks or degrades a sacred figure"),
    (r"\b(nazi|swastika|kkk|white power|hate symbol)\b", "hate symbol"),
    (r"\b(satan|demon|antichrist)\b[^.?!]{0,30}\b(worship|glorif|exalt|summon)\b", "occult/anti-Christian glorification"),
]

# Likely-offensive depictions -> reframe rather than hard refuse.
_REFRAME = [
    (r"\b(muhammad|mohammed|prophet of islam)\b",
     "Depicting the Prophet Muhammad is deeply offensive in Islam.",
     None),
    (r"\b(god the father|face of god|god almighty('s face)?|depict god)\b",
     "Many Christian traditions avoid literal depictions of God the Father.",
     "a symbolic representation of God's presence (radiant light, clouds, or a dove) rather than a literal figure"),
]


def screen_image_prompt(prompt: str) -> ImageSafetyResult:
    text = prompt.strip()
    if not text:
        return ImageSafetyResult(False, "empty prompt")

    for pat, reason in _BLOCK:
        if re.search(pat, text, re.IGNORECASE):
            return ImageSafetyResult(False, reason)

    for pat, reason, replacement in _REFRAME:
        if re.search(pat, text, re.IGNORECASE):
            if replacement:
                revised = re.sub(pat, replacement, text, flags=re.IGNORECASE)
                return ImageSafetyResult(
                    True, reason, revised_prompt=revised,
                    note=f"{reason} I've reframed the image toward a symbolic depiction.",
                )
            return ImageSafetyResult(False, reason)

    return ImageSafetyResult(True)
