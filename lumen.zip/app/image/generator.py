"""Christian image-generation flow.

This is a *workflow*, not just an API call:

   user prompt
      -> image-safety screen (block / reframe; see safety.image_safety)
      -> theme-aware prompt enrichment (style, reverence, symbolism)
      -> provider (OpenAI Images / Stability if configured)
      -> offline fallback: a deterministic SVG "concept card" so the flow is
         fully demonstrable without any image API or network.

The enrichment step encodes product thinking: Christian imagery has conventions
(reverent, non-idolatrous, symbolically rich) that a naive pass-through would
miss, and the safety step handles "subtle policy violations" before any spend.
"""
from __future__ import annotations

import html
import os
from dataclasses import dataclass, field
from typing import Optional

from ..safety.image_safety import screen_image_prompt

STYLE_SUFFIX = (
    "reverent sacred Christian art, luminous and peaceful, rich symbolism, "
    "fine-art composition, soft divine light, no text, tasteful and non-idolatrous"
)


@dataclass
class ImageResult:
    ok: bool
    provider: str
    final_prompt: str = ""
    image_url: Optional[str] = None
    image_svg: Optional[str] = None      # inline SVG for offline fallback
    note: Optional[str] = None
    refused_reason: Optional[str] = None
    safety: dict = field(default_factory=dict)


def enrich_prompt(prompt: str) -> str:
    base = prompt.strip().rstrip(".")
    return f"{base}, {STYLE_SUFFIX}"


def _placeholder_svg(prompt: str) -> str:
    """Deterministic 'concept card' so the multimodal flow is demonstrable offline."""
    safe = html.escape(prompt[:160])
    words, lines, cur = safe.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > 38:
            lines.append(cur); cur = w
        else:
            cur = (cur + " " + w).strip()
    if cur:
        lines.append(cur)
    tspans = "".join(
        f'<tspan x="320" dy="{0 if i == 0 else 30}">{ln}</tspan>'
        for i, ln in enumerate(lines[:6])
    )
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" width="640" height="400" viewBox="0 0 640 400">'
        '<defs><radialGradient id="g" cx="50%" cy="35%" r="75%">'
        '<stop offset="0%" stop-color="#fff7e6"/>'
        '<stop offset="55%" stop-color="#f0c873"/>'
        '<stop offset="100%" stop-color="#6b4f1d"/>'
        '</radialGradient></defs>'
        '<rect width="640" height="400" fill="url(#g)"/>'
        '<g stroke="#5a3d12" stroke-width="10" stroke-linecap="round" opacity="0.85">'
        '<line x1="320" y1="60" x2="320" y2="200"/>'
        '<line x1="260" y1="110" x2="380" y2="110"/></g>'
        '<text x="320" y="270" text-anchor="middle" font-family="Georgia, serif" '
        f'font-size="16" fill="#3a2a0c">{tspans}</text>'
        '<text x="320" y="385" text-anchor="middle" font-family="Georgia, serif" '
        'font-size="12" fill="#4a3815" opacity="0.8">Concept preview (offline mode)</text>'
        '</svg>'
    )


class ImageGenerator:
    def __init__(self):
        self.openai_key = os.environ.get("OPENAI_API_KEY", "").strip()

    def generate(self, prompt: str) -> ImageResult:
        screen = screen_image_prompt(prompt)
        if not screen.allowed:
            return ImageResult(
                ok=False, provider="none", refused_reason=screen.reason,
                note=f"I can't create that image: {screen.reason}.",
                safety={"allowed": False, "reason": screen.reason},
            )

        working_prompt = screen.revised_prompt or prompt
        final_prompt = enrich_prompt(working_prompt)
        safety_meta = {"allowed": True, "reframed": bool(screen.revised_prompt),
                       "note": screen.note}

        if self.openai_key:
            try:
                from openai import OpenAI  # lazy import
                client = OpenAI(api_key=self.openai_key)
                resp = client.images.generate(
                    model=os.environ.get("IMAGE_MODEL", "dall-e-3"),
                    prompt=final_prompt, size="1024x1024", n=1,
                )
                return ImageResult(
                    ok=True, provider="openai-images", final_prompt=final_prompt,
                    image_url=resp.data[0].url, note=screen.note, safety=safety_meta,
                )
            except Exception as e:  # noqa: BLE001 - fall back gracefully
                safety_meta["provider_error"] = str(e)

        return ImageResult(
            ok=True, provider="offline-svg", final_prompt=final_prompt,
            image_svg=_placeholder_svg(final_prompt),
            note=(screen.note or "") + " Showing an offline concept preview; "
            "configure OPENAI_API_KEY for full image generation.",
            safety=safety_meta,
        )
