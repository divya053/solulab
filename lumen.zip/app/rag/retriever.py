"""Hybrid retriever: scripture verses + curated knowledge base.

For a given query we retrieve:
  * the most topically relevant *verses* (full-Bible TF-IDF search), and
  * the most relevant *knowledge-base* entries (church history/doctrine).

The combined context is handed to the responder so answers are grounded in real
text and vetted facts. Retrieval is pure-Python and offline; an embedding-based
backend can be swapped in behind the same interface when an API key is present.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass

from ..scripture.store import ScriptureStore
from .knowledge_base import KNOWLEDGE_BASE, KBEntry

_WORD_RE = re.compile(r"[a-z']+")
_STOP = {"the", "a", "an", "of", "to", "and", "is", "are", "what", "who", "how",
         "when", "why", "do", "does", "did", "was", "were", "in", "on", "for",
         "about", "tell", "me", "i", "you", "it", "that", "this", "with", "can"}


def _tokens(text: str) -> list[str]:
    return [w for w in _WORD_RE.findall(text.lower()) if w not in _STOP and len(w) > 1]


# Modern query terms rarely appear verbatim in the KJV ("anxiety", "depression").
# This light topical map expands the *verse* query toward archaic KJV vocabulary so
# lexical retrieval surfaces the passages a user actually means. It is intentionally
# small and transparent; a dense-embedding backend would remove the need for it.
TOPIC_EXPANSION = {
    "anxiety": "afraid fear careful thought peace troubled",
    "anxious": "afraid fear careful thought peace troubled",
    "worry": "careful thought afraid fear take no thought",
    "worried": "careful thought afraid fear",
    "stress": "afraid weary heavy laden rest peace",
    "depression": "downcast heavy soul cast down despair comfort",
    "depressed": "downcast heavy soul cast down despair",
    "fear": "afraid fear not dismayed",
    "afraid": "fear not afraid dismayed",
    "lonely": "alone forsaken comfort forsake",
    "loneliness": "alone forsaken comfort",
    "grief": "weep mourn comfort sorrow tears",
    "grieving": "weep mourn comfort sorrow",
    "death": "die death grave resurrection life",
    "forgiveness": "forgive forgiven mercy sin",
    "money": "riches mammon treasure money",
    "marriage": "wife husband marriage one flesh",
    "anger": "wrath angry slow anger",
    "patience": "patient longsuffering wait",
    "hope": "hope trust wait expectation",
    "love": "love charity beloved",
    "faith": "faith believe trust",
    "courage": "strong courage fear not dismayed",
    "guidance": "guide path lead way counsel",
    "purpose": "purpose called work appointed",
    "healing": "heal healed whole sick",
}


def _expand_query(query: str) -> str:
    extra = []
    for tok in _WORD_RE.findall(query.lower()):
        if tok in TOPIC_EXPANSION:
            extra.append(TOPIC_EXPANSION[tok])
    return query + (" " + " ".join(extra) if extra else "")


@dataclass
class RetrievedContext:
    verses: list[dict]
    kb: list[dict]

    def is_empty(self) -> bool:
        return not self.verses and not self.kb

    def as_prompt_block(self) -> str:
        lines: list[str] = []
        if self.verses:
            lines.append("Relevant scripture (verified KJV text):")
            for v in self.verses:
                lines.append(f"- {v['reference']}: \"{v['text']}\"")
        if self.kb:
            lines.append("\nRelevant background (vetted knowledge base):")
            for k in self.kb:
                lines.append(f"- {k['title']}: {k['text']}")
        return "\n".join(lines)


class Retriever:
    def __init__(self, store: ScriptureStore, kb: list[KBEntry] = KNOWLEDGE_BASE):
        self.store = store
        self.kb = kb
        self._build_kb_index()

    def _build_kb_index(self) -> None:
        self._kb_tokens: list[set[str]] = []
        df: dict[str, int] = {}
        for e in self.kb:
            toks = set(_tokens(e.title + " " + e.text) + list(e.tags))
            self._kb_tokens.append(toks)
            for t in toks:
                df[t] = df.get(t, 0) + 1
        n = max(1, len(self.kb))
        self._kb_idf = {t: math.log(1 + n / (1 + c)) for t, c in df.items()}

    def _search_kb(self, query: str, top_k: int) -> list[dict]:
        q = set(_tokens(query))
        if not q:
            return []
        scored = []
        for i, toks in enumerate(self._kb_tokens):
            score = sum(self._kb_idf.get(t, 0.0) for t in q if t in toks)
            if score > 0:
                scored.append((score, i))
        scored.sort(reverse=True)
        out = []
        for score, i in scored[:top_k]:
            e = self.kb[i]
            out.append({"id": e.id, "title": e.title, "text": e.text,
                        "score": round(score, 3)})
        return out

    def retrieve(self, query: str, n_verses: int = 4, n_kb: int = 3) -> RetrievedContext:
        verses = self.store.search(_expand_query(query), top_k=n_verses)
        kb = self._search_kb(query, top_k=n_kb)
        return RetrievedContext(verses=verses, kb=kb)
