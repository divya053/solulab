"""Curated theological / historical knowledge base for grounding.

Scripture grounding handles verse-level claims. This KB grounds the *other*
common hallucination surface: church history, creeds, councils, and
denominational positions ("when was the Nicene Creed written?", "what do
Catholics believe about Mary?").

Each entry is a short, sourced, factual statement. The retriever surfaces the
most relevant entries so the model (or the offline responder) answers from
vetted material instead of inventing dates and councils. Entries are concise on
purpose — this is a demonstrator, not an encyclopedia, and it is easy to extend.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class KBEntry:
    id: str
    title: str
    text: str
    tags: tuple[str, ...]


KNOWLEDGE_BASE: list[KBEntry] = [
    KBEntry("nicene_creed", "The Nicene Creed",
            "The Nicene Creed was first adopted at the First Council of Nicaea in AD 325 "
            "and expanded at the First Council of Constantinople in AD 381. It affirms the "
            "Trinity and the full divinity of Christ ('begotten, not made, of one being "
            "with the Father').",
            ("creed", "trinity", "council", "history", "nicaea", "nicene")),
    KBEntry("apostles_creed", "The Apostles' Creed",
            "The Apostles' Creed is an early statement of Christian belief that took its "
            "current form by roughly the 4th-8th centuries. Despite the legend, it was not "
            "literally written by the twelve apostles. It summarizes belief in the Father, "
            "Son, and Holy Spirit, Christ's death, resurrection, and return.",
            ("creed", "history", "belief", "apostles")),
    KBEntry("council_chalcedon", "Council of Chalcedon (AD 451)",
            "The Council of Chalcedon (AD 451) defined that Christ is one person in two "
            "natures, fully God and fully man, 'without confusion, change, division, or "
            "separation.' Most of Eastern (Oriental) Orthodoxy did not accept its wording.",
            ("council", "christology", "history", "incarnation")),
    KBEntry("reformation", "The Protestant Reformation",
            "The Protestant Reformation is conventionally dated to 1517, when Martin Luther "
            "circulated his Ninety-five Theses. Its core principles are often summarized as "
            "the 'five solas' (scripture, faith, grace, Christ, and the glory of God alone).",
            ("reformation", "protestant", "luther", "history")),
    KBEntry("great_schism", "The Great Schism (1054)",
            "The East-West Schism of 1054 marked the formal break between the Roman Catholic "
            "Church and the Eastern Orthodox Church, over issues including papal authority "
            "and the 'filioque' clause added to the Nicene Creed in the West.",
            ("schism", "catholic", "orthodox", "history")),
    KBEntry("trinity", "The doctrine of the Trinity",
            "Historic Christianity confesses one God in three persons - Father, Son, and "
            "Holy Spirit - co-equal and co-eternal. This is shared across Catholic, "
            "Orthodox, and Protestant traditions. Denying it (e.g. Arianism, modalism) was "
            "judged heretical by the early councils.",
            ("trinity", "doctrine", "god", "orthodoxy")),
    KBEntry("salvation_views", "Faith, works, and salvation",
            "Protestants emphasize justification by faith alone (sola fide). Catholics and "
            "Orthodox teach that salvation is by grace through faith expressed in works and "
            "the sacraments; they reject 'faith alone' as a complete formula. All affirm "
            "salvation is ultimately God's gift of grace, not earned merit.",
            ("salvation", "faith", "works", "grace", "saved", "catholic", "protestant", "orthodox")),
    KBEntry("mary_catholic", "Catholic and Orthodox teaching on Mary",
            "Catholics venerate (not worship) Mary, holding doctrines such as her "
            "Immaculate Conception and Assumption. The Orthodox honor her as Theotokos "
            "('God-bearer'). Most Protestants honor Mary but reject doctrines they see as "
            "lacking explicit scriptural basis.",
            ("mary", "catholic", "orthodox", "protestant", "veneration")),
    KBEntry("sacraments", "Sacraments / ordinances",
            "Catholics and Orthodox recognize seven sacraments. Most Protestants recognize "
            "two ordinances instituted by Christ - baptism and the Lord's Supper / "
            "Communion - though views on their meaning vary.",
            ("sacrament", "baptism", "communion", "eucharist")),
    KBEntry("canon", "The biblical canon",
            "Protestant Bibles contain 66 books. Catholic Bibles add seven deuterocanonical "
            "books (e.g. Tobit, Wisdom, Sirach, 1-2 Maccabees); Orthodox Bibles include "
            "those and a few more. The bundled text in this app is the Protestant KJV.",
            ("canon", "deuterocanon", "apocrypha", "bible", "books")),
    KBEntry("hell_views", "Christian views on hell",
            "Historic Christianity affirms final judgment. Within orthodoxy there is "
            "genuine debate: eternal conscious torment (the traditional/majority view), "
            "annihilationism (the lost ultimately cease to exist), and a minority "
            "hopeful-universalism. These are interpretive differences, not all heresy.",
            ("hell", "judgment", "eternity", "suffering", "annihilation", "universalism")),
    KBEntry("problem_of_evil", "Suffering and the problem of evil",
            "Christianity does not claim suffering is good, but that God is present in it and "
            "can redeem it. Key resources include the book of Job, the lament Psalms, and "
            "above all the cross - God entering human suffering. Pastoral care matters more "
            "than tidy explanations here.",
            ("suffering", "evil", "pain", "job", "lament", "theodicy")),
    KBEntry("gospels", "The four Gospels",
            "The New Testament contains four Gospels - Matthew, Mark, Luke, and John. Mark "
            "is generally considered the earliest. They are the primary accounts of Jesus' "
            "life, teaching, death, and resurrection.",
            ("gospel", "jesus", "new testament", "history")),
]


def all_tags() -> set[str]:
    tags: set[str] = set()
    for e in KNOWLEDGE_BASE:
        tags.update(e.tags)
    return tags
