"""Conversation memory.

A simple, dependency-free per-session store with:
  * bounded message history (keeps the last N turns to control prompt size),
  * a lightweight running "profile" (the user's chosen denomination, recurring
    topics) that survives truncation so long chats stay coherent.

In production this would be backed by Redis/Postgres + optional vector recall of
older turns; the interface here is deliberately swappable.
"""
from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Message:
    role: str            # "user" | "assistant"
    content: str
    ts: float = field(default_factory=time.time)


@dataclass
class Session:
    session_id: str
    denomination: str = "ecumenical"
    tone: str = "warm, pastoral, encouraging"
    messages: deque = field(default_factory=lambda: deque(maxlen=40))
    topics: list[str] = field(default_factory=list)

    def add(self, role: str, content: str) -> None:
        self.messages.append(Message(role, content))

    def history(self, limit: int = 12) -> list[Message]:
        msgs = list(self.messages)
        return msgs[-limit:]

    def summary(self) -> str:
        if not self.topics:
            return ""
        return "Recurring topics this conversation: " + ", ".join(self.topics[-6:])


class MemoryStore:
    def __init__(self):
        self._sessions: dict[str, Session] = {}
        self._lock = threading.Lock()

    def get(self, session_id: str, create: bool = True) -> Optional[Session]:
        with self._lock:
            s = self._sessions.get(session_id)
            if s is None and create:
                s = Session(session_id=session_id)
                self._sessions[session_id] = s
            return s

    def note_topic(self, session_id: str, topic: str) -> None:
        s = self.get(session_id)
        if s and topic and topic not in s.topics:
            s.topics.append(topic)


_store = MemoryStore()


def get_memory() -> MemoryStore:
    return _store
