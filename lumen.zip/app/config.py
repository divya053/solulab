"""Runtime configuration surfaced to the API/UI for transparency."""
from __future__ import annotations

import os


def runtime_info() -> dict:
    provider = os.environ.get("LLM_PROVIDER", "").strip().lower()
    has_anthropic = bool(os.environ.get("ANTHROPIC_API_KEY", "").strip())
    has_openai = bool(os.environ.get("OPENAI_API_KEY", "").strip())
    if provider == "offline" or (not provider and not has_anthropic and not has_openai):
        active = "offline-grounded"
    elif provider:
        active = provider
    elif has_anthropic:
        active = "anthropic"
    else:
        active = "openai"
    return {
        "llm_provider": active,
        "image_generation": "openai-images" if has_openai else "offline-svg",
        "scripture_translation": "KJV (66 books, verified)",
        "mode": "offline-first" if active == "offline-grounded" else "api-backed",
    }
