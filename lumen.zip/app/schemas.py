"""Pydantic request/response models for the HTTP API."""
from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=4000)
    session_id: str = Field(default="default", max_length=128)
    denomination: Optional[str] = None


class ChatResponse(BaseModel):
    reply: str
    blocked: bool
    denomination: str
    trace: dict[str, Any]


class VerseLookupResponse(BaseModel):
    reference: str
    found: bool
    text: Optional[str] = None
    message: Optional[str] = None


class SearchResponse(BaseModel):
    query: str
    results: list[dict[str, Any]]


class ImageRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=1000)


class ImageResponse(BaseModel):
    ok: bool
    provider: str
    final_prompt: str = ""
    image_url: Optional[str] = None
    image_svg: Optional[str] = None
    note: Optional[str] = None
    refused_reason: Optional[str] = None
    safety: dict[str, Any] = {}
