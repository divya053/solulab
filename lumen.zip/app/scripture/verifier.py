"""Scripture citation verifier — the core anti-hallucination mechanism.

Given any text (typically an LLM's answer), this finds every Bible reference,
and classifies each one against the ground-truth KJV corpus:

    VALID        - reference exists; if text is quoted, it matches the KJV.
    OUT_OF_BOUNDS- book exists but chapter/verse is outside the real canon
                   (e.g. "John 3:99")  -> a fabricated reference.
    UNKNOWN_BOOK - book name isn't in the canon (e.g. "Hezekiah 3:1").
    MISQUOTED    - reference exists but the quoted wording diverges from KJV
                   beyond tolerance  -> likely a hallucinated paraphrase
                   presented as a direct quote.

The pipeline uses this both to (a) append trustworthy citations and (b) attach
warnings / corrections so fabricated scripture never passes silently.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from enum import Enum
from typing import Optional

from .canon import Reference, extract_references
from .store import ScriptureStore


class CitationStatus(str, Enum):
    VALID = "valid"
    OUT_OF_BOUNDS = "out_of_bounds"
    UNKNOWN_BOOK = "unknown_book"
    MISQUOTED = "misquoted"


@dataclass
class CitationCheck:
    reference: str
    status: CitationStatus
    canonical_text: Optional[str] = None
    quoted_text: Optional[str] = None
    similarity: Optional[float] = None
    message: str = ""


@dataclass
class VerificationResult:
    checks: list[CitationCheck] = field(default_factory=list)

    @property
    def has_problems(self) -> bool:
        return any(c.status != CitationStatus.VALID for c in self.checks)

    @property
    def valid_citations(self) -> list[CitationCheck]:
        return [c for c in self.checks if c.status == CitationStatus.VALID]

    @property
    def problems(self) -> list[CitationCheck]:
        return [c for c in self.checks if c.status != CitationStatus.VALID]


# Similarity below this (when a quote is detected) is treated as a misquote.
MISQUOTE_THRESHOLD = 0.62

_NORMALIZE_RE = re.compile(r"[^a-z0-9 ]+")


def _normalize(text: str) -> str:
    return _NORMALIZE_RE.sub(" ", text.lower()).strip()


def _similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, _normalize(a), _normalize(b)).ratio()


class ScriptureVerifier:
    def __init__(self, store: ScriptureStore):
        self.store = store

    def _find_quote_near(self, text: str, ref_str: str) -> Optional[str]:
        """Heuristically extract a quoted string associated with a reference.

        We look for quotation marks near the reference. This catches the common
        pattern:  "<quote>" (Book C:V)  or  Book C:V says "<quote>".
        """
        idx = text.find(ref_str)
        if idx == -1:
            return None
        window = text[max(0, idx - 400): idx + 400]
        quotes = re.findall(r"[\"“]([^\"”“]{8,400})[\"”]", window)
        if quotes:
            return max(quotes, key=len)
        return None

    def verify_text(self, text: str) -> VerificationResult:
        result = VerificationResult()
        refs = extract_references(text, self.store.book_names)
        for ref in refs:
            result.checks.append(self._verify_reference(text, ref))
        return result

    def _verify_reference(self, text: str, ref: Reference) -> CitationCheck:
        ref_str = str(ref)
        if not self.store.book_exists(ref.book):
            return CitationCheck(
                reference=ref_str, status=CitationStatus.UNKNOWN_BOOK,
                message=f'"{ref.book}" is not a book of the canonical Bible.',
            )
        if not self.store.reference_in_bounds(ref):
            cc = self.store.chapter_count(ref.book)
            detail = f"{ref.book} has {cc} chapters"
            if 1 <= ref.chapter <= cc and ref.verse_start is not None:
                detail += f"; chapter {ref.chapter} has {self.store.verse_count(ref.book, ref.chapter)} verses"
            return CitationCheck(
                reference=ref_str, status=CitationStatus.OUT_OF_BOUNDS,
                message=f"{ref_str} is outside the canon ({detail}).",
            )
        canonical = self.store.get_passage(ref)
        quote = self._find_quote_near(text, ref_str)
        if quote and canonical:
            sim = _similarity(quote, canonical)
            if sim < MISQUOTE_THRESHOLD:
                return CitationCheck(
                    reference=ref_str, status=CitationStatus.MISQUOTED,
                    canonical_text=canonical, quoted_text=quote, similarity=round(sim, 2),
                    message=(f"The wording attributed to {ref_str} does not match the KJV "
                             f"(similarity {sim:.2f})."),
                )
            return CitationCheck(
                reference=ref_str, status=CitationStatus.VALID,
                canonical_text=canonical, quoted_text=quote, similarity=round(sim, 2),
            )
        return CitationCheck(
            reference=ref_str, status=CitationStatus.VALID, canonical_text=canonical,
        )

    def annotate(self, text: str, result: VerificationResult) -> str:
        """Append a transparency footer documenting citation checks."""
        if not result.checks:
            return text
        lines = ["", "---", "**Scripture check** (verified against the KJV):"]
        for c in result.checks:
            if c.status == CitationStatus.VALID:
                snippet = (c.canonical_text or "")[:200]
                lines.append(f"- ✅ **{c.reference}** — “{snippet}”")
            elif c.status == CitationStatus.MISQUOTED:
                lines.append(
                    f"- ⚠️ **{c.reference}** — quoted wording does not match KJV. "
                    f"Actual: “{(c.canonical_text or '')[:200]}”"
                )
            else:
                lines.append(f"- ❌ **{c.reference}** — {c.message}")
        return text + "\n".join(lines)
