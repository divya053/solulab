"""Loads the KJV corpus and provides verse lookup + keyword search.

The store is the single source of truth for scripture text.  Every citation the
system emits is resolved through here, which is what lets us answer the
question "does this verse actually exist, and does the quoted text match?"
"""
from __future__ import annotations

import json
import math
import os
import re
from functools import lru_cache
from typing import Optional

from .canon import Reference

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "kjv.json")

_WORD_RE = re.compile(r"[a-z']+")
# Words too common to be useful for verse search.
_STOP = {
    "the", "and", "of", "to", "a", "in", "that", "he", "shall", "unto", "for",
    "i", "his", "they", "be", "is", "him", "not", "them", "it", "with", "all",
    "thou", "thy", "thee", "was", "which", "my", "me", "but", "ye", "their",
    "have", "will", "as", "are", "this", "we", "from", "then", "you", "your",
}


def _tokens(text: str) -> list[str]:
    return [w for w in _WORD_RE.findall(text.lower()) if w not in _STOP and len(w) > 1]


class ScriptureStore:
    def __init__(self, path: str = DATA_PATH):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.translation = data["translation"]
        # name -> list[chapter][verse] (0-indexed lists, 1-indexed references)
        self._books: dict[str, list[list[str]]] = {}
        self._order: dict[str, int] = {}
        for b in data["books"]:
            self._books[b["name"]] = b["chapters"]
            self._order[b["name"]] = b["order"]
        self.book_names: set[str] = set(self._books.keys())
        self._build_index()

    # -- structural validation ------------------------------------------------
    def book_exists(self, book: str) -> bool:
        return book in self._books

    def chapter_count(self, book: str) -> int:
        return len(self._books.get(book, []))

    def verse_count(self, book: str, chapter: int) -> int:
        chapters = self._books.get(book)
        if not chapters or chapter < 1 or chapter > len(chapters):
            return 0
        return len(chapters[chapter - 1])

    def reference_in_bounds(self, ref: Reference) -> bool:
        """True only if the chapter (and verse, if given) exist in the canon."""
        if not self.book_exists(ref.book):
            return False
        if ref.chapter < 1 or ref.chapter > self.chapter_count(ref.book):
            return False
        if ref.verse_start is None:
            return True
        n = self.verse_count(ref.book, ref.chapter)
        end = ref.verse_end or ref.verse_start
        return 1 <= ref.verse_start <= end <= n

    # -- text retrieval -------------------------------------------------------
    def get_verse(self, book: str, chapter: int, verse: int) -> Optional[str]:
        if self.verse_count(book, chapter) >= verse >= 1:
            return self._books[book][chapter - 1][verse - 1]
        return None

    def get_passage(self, ref: Reference) -> Optional[str]:
        """Return the joined text for a reference, or None if out of bounds."""
        if not self.reference_in_bounds(ref):
            return None
        if ref.verse_start is None:
            return " ".join(self._books[ref.book][ref.chapter - 1])
        end = ref.verse_end or ref.verse_start
        parts = [
            self._books[ref.book][ref.chapter - 1][v - 1]
            for v in range(ref.verse_start, end + 1)
        ]
        return " ".join(parts)

    # -- keyword search (offline RAG over the full Bible) ---------------------
    def _build_index(self) -> None:
        """A lightweight inverted index + per-verse token sets for TF-IDF-ish search."""
        self._verses: list[tuple[str, int, int, str]] = []  # (book, ch, vs, text)
        self._verse_tokens: list[set[str]] = []
        df: dict[str, int] = {}
        for name, chapters in self._books.items():
            for ci, ch in enumerate(chapters, start=1):
                for vi, text in enumerate(ch, start=1):
                    toks = set(_tokens(text))
                    self._verses.append((name, ci, vi, text))
                    self._verse_tokens.append(toks)
                    for t in toks:
                        df[t] = df.get(t, 0) + 1
        n = len(self._verses)
        self._idf = {t: math.log(1 + n / (1 + c)) for t, c in df.items()}
        self._inverted: dict[str, list[int]] = {}
        for idx, toks in enumerate(self._verse_tokens):
            for t in toks:
                self._inverted.setdefault(t, []).append(idx)

    def search(self, query: str, top_k: int = 5) -> list[dict]:
        """Return the top_k most relevant verses for a topical query.

        Pure-Python TF-IDF cosine-ish scoring over a candidate set gathered
        from the inverted index.  No external embedding service required, so
        topical grounding works fully offline.
        """
        q_tokens = _tokens(query)
        if not q_tokens:
            return []
        q_weights = {t: self._idf.get(t, 0.0) for t in set(q_tokens)}
        candidates: set[int] = set()
        for t in q_weights:
            candidates.update(self._inverted.get(t, []))
        scored: list[tuple[float, int]] = []
        for idx in candidates:
            toks = self._verse_tokens[idx]
            score = sum(w for t, w in q_weights.items() if t in toks)
            score /= (1 + 0.02 * len(toks))  # length normalization
            if score > 0:
                scored.append((score, idx))
        scored.sort(reverse=True)
        results = []
        for score, idx in scored[:top_k]:
            book, ch, vs, text = self._verses[idx]
            results.append({
                "reference": f"{book} {ch}:{vs}",
                "book": book, "chapter": ch, "verse": vs,
                "text": text, "score": round(score, 3),
            })
        return results


@lru_cache(maxsize=1)
def get_store() -> ScriptureStore:
    return ScriptureStore()
