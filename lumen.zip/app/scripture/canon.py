"""Canonical Bible reference data and a tolerant reference parser.

This module is the first line of defense against *fabricated citations*.
Before we ever trust a verse reference (whether it came from a user or from an
LLM), we check that the book exists and that the chapter/verse numbers fall
within the real bounds of the canon.  A reference like "Hezekiah 3:16" or
"John 3:99" is rejected here without needing the full text.

The parser uses a token-scan (not one big regex) so it can:
  * resolve multi-word and abbreviated books ("1 Cor", "Song of Solomon", "Jhn"),
  * avoid swallowing ordinary words ("Read John 3:99" -> John, not "Read John"),
  * still surface *fabricated* book names ("Hezekiah 3:5") so the verifier can
    flag them, by emitting proper-noun + chapter:verse candidates as references
    even when the book is unknown.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

# Common abbreviations / alternate spellings -> canonical book name.
# Kept intentionally broad so user input ("Jhn", "Ps", "1 Cor") still resolves.
BOOK_ALIASES = {
    "gen": "Genesis", "ge": "Genesis", "gn": "Genesis",
    "ex": "Exodus", "exo": "Exodus", "exod": "Exodus",
    "lev": "Leviticus", "lv": "Leviticus",
    "num": "Numbers", "nu": "Numbers", "nm": "Numbers",
    "deut": "Deuteronomy", "dt": "Deuteronomy",
    "josh": "Joshua", "jos": "Joshua",
    "judg": "Judges", "jdg": "Judges",
    "rth": "Ruth", "ru": "Ruth",
    "1sam": "1 Samuel", "1sa": "1 Samuel", "1 sam": "1 Samuel",
    "2sam": "2 Samuel", "2sa": "2 Samuel", "2 sam": "2 Samuel",
    "1kgs": "1 Kings", "1ki": "1 Kings", "1 kgs": "1 Kings", "1 kings": "1 Kings",
    "2kgs": "2 Kings", "2ki": "2 Kings", "2 kgs": "2 Kings", "2 kings": "2 Kings",
    "1chr": "1 Chronicles", "1ch": "1 Chronicles",
    "2chr": "2 Chronicles", "2ch": "2 Chronicles",
    "ezr": "Ezra", "neh": "Nehemiah", "est": "Esther", "esth": "Esther",
    "jb": "Job", "ps": "Psalms", "psa": "Psalms", "psalm": "Psalms", "pss": "Psalms",
    "prov": "Proverbs", "prv": "Proverbs", "pr": "Proverbs",
    "eccl": "Ecclesiastes", "ecc": "Ecclesiastes", "qoh": "Ecclesiastes",
    "song": "Song of Solomon", "sos": "Song of Solomon", "canticles": "Song of Solomon",
    "isa": "Isaiah", "is": "Isaiah",
    "jer": "Jeremiah", "lam": "Lamentations", "ezek": "Ezekiel", "eze": "Ezekiel",
    "dan": "Daniel", "dn": "Daniel",
    "hos": "Hosea", "jl": "Joel", "am": "Amos", "ob": "Obadiah", "obad": "Obadiah",
    "jon": "Jonah", "mic": "Micah", "nah": "Nahum", "hab": "Habakkuk",
    "zeph": "Zephaniah", "zep": "Zephaniah", "hag": "Haggai",
    "zech": "Zechariah", "zec": "Zechariah", "mal": "Malachi",
    "mt": "Matthew", "matt": "Matthew", "mk": "Mark", "mrk": "Mark",
    "lk": "Luke", "luk": "Luke", "jn": "John", "jhn": "John", "joh": "John",
    "act": "Acts", "rom": "Romans", "ro": "Romans",
    "1cor": "1 Corinthians", "1co": "1 Corinthians", "1 cor": "1 Corinthians",
    "2cor": "2 Corinthians", "2co": "2 Corinthians", "2 cor": "2 Corinthians",
    "gal": "Galatians", "eph": "Ephesians", "phil": "Philippians", "php": "Philippians",
    "col": "Colossians",
    "1thess": "1 Thessalonians", "1th": "1 Thessalonians", "1 thess": "1 Thessalonians",
    "2thess": "2 Thessalonians", "2th": "2 Thessalonians", "2 thess": "2 Thessalonians",
    "1tim": "1 Timothy", "1ti": "1 Timothy", "1 tim": "1 Timothy",
    "2tim": "2 Timothy", "2ti": "2 Timothy", "2 tim": "2 Timothy",
    "tit": "Titus", "phlm": "Philemon", "phm": "Philemon",
    "heb": "Hebrews", "jas": "James", "jms": "James",
    "1pet": "1 Peter", "1pe": "1 Peter", "1 pet": "1 Peter",
    "2pet": "2 Peter", "2pe": "2 Peter", "2 pet": "2 Peter",
    "1jn": "1 John", "1jo": "1 John", "1 jn": "1 John", "1 john": "1 John",
    "2jn": "2 John", "2jo": "2 John", "2 jn": "2 John", "2 john": "2 John",
    "3jn": "3 John", "3jo": "3 John", "3 jn": "3 John", "3 john": "3 John",
    "jud": "Jude", "rev": "Revelation", "rv": "Revelation", "apoc": "Revelation",
}

# Matches a chapter / verse / range immediately after a book token.
# Allows optional leading whitespace: "John" + " 3:16-18".
_NUM_RE = re.compile(r"\s{0,3}(\d{1,3})(?::(\d{1,3}))?(?:\s?[-–]\s?(\d{1,3}))?")

# Word tokens (letters + digits, e.g. "John", "1", "Corinthians").
_TOKEN_RE = re.compile(r"[A-Za-z0-9]+")

# Capitalized words that look like a book but are not, to avoid false "unknown book"
# flags on sentences like "Chapter 3: a new beginning".
_NONBOOK = {
    "Chapter", "Verse", "Page", "Number", "No", "Room", "Day", "Time", "Hour",
    "Year", "Verily", "Selah", "Section", "Part", "Volume", "Line", "Note",
}

# Proper-noun shape for an unknown-book candidate.
_PROPER_RE = re.compile(r"^[A-Z][a-z]{2,}$")


@dataclass(frozen=True)
class Reference:
    book: str
    chapter: int
    verse_start: Optional[int] = None
    verse_end: Optional[int] = None

    def __str__(self) -> str:
        if self.verse_start is None:
            return f"{self.book} {self.chapter}"
        if self.verse_end and self.verse_end != self.verse_start:
            return f"{self.book} {self.chapter}:{self.verse_start}-{self.verse_end}"
        return f"{self.book} {self.chapter}:{self.verse_start}"


def normalize_book(raw: str, known_books: set[str]) -> Optional[str]:
    """Resolve a raw book token to a canonical book name, or None if unknown."""
    token = raw.strip().rstrip(".").strip()
    for b in known_books:
        if b.lower() == token.lower():
            return b
    key = token.lower().replace(".", "")
    if key in BOOK_ALIASES and BOOK_ALIASES[key] in known_books:
        return BOOK_ALIASES[key]
    collapsed = key.replace(" ", "")
    if collapsed in BOOK_ALIASES and BOOK_ALIASES[collapsed] in known_books:
        return BOOK_ALIASES[collapsed]
    for b in known_books:
        if b.lower().replace(" ", "") == collapsed:
            return b
    return None


def _make_ref(book: str, m: re.Match) -> Reference:
    chapter = int(m.group(1))
    vs = int(m.group(2)) if m.group(2) else None
    ve = int(m.group(3)) if m.group(3) else vs
    return Reference(book, chapter, vs, ve)


def extract_references(text: str, known_books: set[str]) -> list[Reference]:
    """Find references in free text and resolve their book names.

    Returns references for *recognized* books, and also for proper-noun +
    chapter:verse candidates whose book is unknown (so the verifier can flag a
    fabricated reference like "Hezekiah 3:5").
    """
    tokens = [(m.group(0), m.start(), m.end()) for m in _TOKEN_RE.finditer(text)]
    n = len(tokens)
    out: list[Reference] = []
    seen: set[tuple] = set()

    def add(ref: Reference) -> None:
        key = (ref.book, ref.chapter, ref.verse_start, ref.verse_end)
        if key not in seen:
            seen.add(key)
            out.append(ref)

    i = 0
    while i < n:
        advanced = False
        # Longest-first so "1 Corinthians" / "Song of Solomon" win over "1" / "Song".
        for span in (3, 2, 1):
            if i + span > n:
                continue
            phrase = " ".join(tok[0] for tok in tokens[i:i + span])
            book = normalize_book(phrase, known_books)
            if not book:
                continue
            m = _NUM_RE.match(text, tokens[i + span - 1][2])
            if m:
                add(_make_ref(book, m))
                i += span
                advanced = True
                break
        if advanced:
            continue

        # Unknown-book candidate: proper noun directly followed by chapter:verse
        # (a verse number / colon is required to avoid flagging "Chapter 3").
        word, _start, end = tokens[i]
        if _PROPER_RE.match(word) and word not in _NONBOOK:
            m = _NUM_RE.match(text, end)
            if m and m.group(2):
                add(_make_ref(word, m))
        i += 1

    return out
