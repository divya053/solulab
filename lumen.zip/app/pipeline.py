"""Chat orchestration pipeline.

End-to-end flow for a chat turn:

  1. INPUT MODERATION   - refuse/redirect harmful input early; flag sensitive
                          topics for careful handling.
  2. MEMORY             - load session, denomination lens, running summary.
  3. RETRIEVAL (RAG)    - pull verified verses + KB context for the query.
  4. GENERATION         - provider (LLM or offline grounded responder) answers
                          with the assembled system prompt + grounding context.
  5. SCRIPTURE VERIFY   - check every citation against the KJV; annotate /flag
                          fabricated or misquoted references.
  6. OUTPUT MODERATION  - last-mile safety check on generated text.
  7. PERSIST            - store the exchange in memory.

The pipeline returns a structured trace so the UI (and the eval harness) can
show exactly what each stage decided — the transparency is part of the product.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

from .denomination.profiles import get_denomination
from .llm.base import GenerationRequest
from .llm.factory import build_provider
from .memory.store import get_memory
from .prompts import build_system_prompt
from .rag.retriever import Retriever
from .safety.moderation import Action, Moderator
from .scripture.store import get_store
from .scripture.verifier import ScriptureVerifier


@dataclass
class ChatTrace:
    moderation_input: dict = field(default_factory=dict)
    retrieval: dict = field(default_factory=dict)
    provider: str = ""
    scripture_check: dict = field(default_factory=dict)
    moderation_output: dict = field(default_factory=dict)
    flags: list[str] = field(default_factory=list)


@dataclass
class ChatResult:
    reply: str
    blocked: bool
    trace: ChatTrace
    denomination: str


_TOPIC_RE = re.compile(r"\b([A-Z][a-z]{4,})\b")


class ChatPipeline:
    def __init__(self):
        self.store = get_store()
        self.verifier = ScriptureVerifier(self.store)
        self.retriever = Retriever(self.store)
        self.moderator = Moderator()
        self.memory = get_memory()
        self.provider = build_provider()

    def chat(self, session_id: str, message: str,
             denomination: Optional[str] = None) -> ChatResult:
        trace = ChatTrace()
        session = self.memory.get(session_id)
        if denomination:
            session.denomination = denomination
        denom = get_denomination(session.denomination)

        # 1. INPUT MODERATION ------------------------------------------------
        mod_in = self.moderator.screen_input(message)
        trace.moderation_input = {
            "action": mod_in.action.value,
            "hits": [{"category": h.category.value, "reason": h.reason} for h in mod_in.hits],
        }
        if mod_in.blocked:
            session.add("user", message)
            session.add("assistant", mod_in.response or "")
            trace.flags.append(f"input_blocked:{mod_in.action.value}")
            return ChatResult(reply=mod_in.response or "", blocked=True,
                              trace=trace, denomination=denom.key)

        # 2. RETRIEVAL -------------------------------------------------------
        ctx = self.retriever.retrieve(message)
        trace.retrieval = {
            "verses": [{"reference": v["reference"], "score": v["score"]} for v in ctx.verses],
            "kb": [{"id": k["id"], "score": k["score"]} for k in ctx.kb],
        }

        # 3. BUILD PROMPT + GENERATE ----------------------------------------
        system = build_system_prompt(denom, session.summary())
        history = [{"role": m.role, "content": m.content} for m in session.history()]
        history.append({"role": "user", "content": message})
        req = GenerationRequest(
            system=system,
            messages=history,
            context_block=ctx.as_prompt_block(),
            grounding_verses=ctx.verses,
            grounding_kb=ctx.kb,
            extra_guidance=mod_in.guidance or "",
        )
        try:
            raw = self.provider.generate(req)
        except Exception as e:  # noqa: BLE001 - never hard-fail a turn
            from .llm.offline_provider import OfflineProvider
            raw = OfflineProvider().generate(req)
            trace.flags.append(f"provider_fallback:{type(e).__name__}")
        trace.provider = self.provider.name

        # 4. SCRIPTURE VERIFICATION -----------------------------------------
        verification = self.verifier.verify_text(raw)
        trace.scripture_check = {
            "checks": [
                {"reference": c.reference, "status": c.status.value,
                 "similarity": c.similarity, "message": c.message}
                for c in verification.checks
            ],
            "has_problems": verification.has_problems,
        }
        if verification.has_problems:
            trace.flags.append("scripture_problems")
        reply = self.verifier.annotate(raw, verification)

        # 5. OUTPUT MODERATION ----------------------------------------------
        mod_out = self.moderator.screen_output(raw)
        trace.moderation_output = {"action": mod_out.action.value}
        if mod_out.action == Action.REFUSE:
            trace.flags.append("output_blocked")
            reply = mod_out.response or ""
            blocked = True
        else:
            blocked = False

        # 6. PERSIST ---------------------------------------------------------
        session.add("user", message)
        session.add("assistant", reply)
        for topic in set(_TOPIC_RE.findall(message)):
            self.memory.note_topic(session_id, topic)

        return ChatResult(reply=reply, blocked=blocked, trace=trace,
                          denomination=denom.key)


_pipeline: Optional[ChatPipeline] = None


def get_pipeline() -> ChatPipeline:
    global _pipeline
    if _pipeline is None:
        _pipeline = ChatPipeline()
    return _pipeline
