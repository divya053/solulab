const sessionId = "web-" + Math.random().toString(36).slice(2, 10);
const $ = (s) => document.querySelector(s);

async function loadMeta() {
  try {
    const [d, h] = await Promise.all([
      fetch("/api/denominations").then(r => r.json()),
      fetch("/api/health").then(r => r.json()),
    ]);
    const sel = $("#denom");
    d.denominations.forEach(x => {
      const o = document.createElement("option");
      o.value = x.key; o.textContent = x.label; sel.appendChild(o);
    });
    $("#mode").textContent = "LLM: " + h.llm_provider;
  } catch (e) { /* offline */ }
}

function escapeHtml(s) {
  return s.replace(/[&<>]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
}

// Minimal markdown: bold, italics, the scripture-check footer, line breaks.
function render(text) {
  let html = escapeHtml(text);
  html = html.replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");
  html = html.replace(/_(.+?)_/g, "<i>$1</i>");
  html = html.replace(/\n---\n/g, "<hr/>");
  html = html.replace(/✅/g, '<span class="tag-ok">✅</span>')
             .replace(/⚠️/g, '<span class="tag-warn">⚠️</span>')
             .replace(/❌/g, '<span class="tag-bad">❌</span>');
  html = html.replace(/\n/g, "<br/>");
  return html;
}

function addMsg(text, who, blocked) {
  const wrap = document.createElement("div");
  wrap.className = "msg " + who + (blocked ? " blocked" : "");
  const b = document.createElement("div");
  b.className = "bubble";
  b.innerHTML = render(text);
  wrap.appendChild(b);
  $("#messages").appendChild(wrap);
  $("#messages").scrollTop = $("#messages").scrollHeight;
  return b;
}

async function send(message) {
  addMsg(message, "user", false);
  const thinking = addMsg("…", "assistant", false);
  try {
    const res = await fetch("/api/chat", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, session_id: sessionId, denomination: $("#denom").value }),
    });
    const data = await res.json();
    thinking.innerHTML = render(data.reply);
    if (data.blocked) thinking.parentElement.classList.add("blocked");
    $("#trace").textContent = JSON.stringify(data.trace, null, 2);
  } catch (e) {
    thinking.textContent = "Network error: " + e.message;
  }
}

$("#chat-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const v = $("#input").value.trim();
  if (!v) return;
  $("#input").value = "";
  send(v);
});

document.querySelectorAll(".examples button").forEach(btn => {
  btn.addEventListener("click", () => send(btn.dataset.q));
});

$("#img-btn").addEventListener("click", async () => {
  const prompt = $("#img-input").value.trim();
  if (!prompt) return;
  const out = $("#img-out");
  out.innerHTML = "Generating…";
  try {
    const data = await fetch("/api/image", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt }),
    }).then(r => r.json());
    out.innerHTML = "";
    if (!data.ok) {
      out.innerHTML = '<div class="note">⛔ ' + escapeHtml(data.note || data.refused_reason) + "</div>";
      return;
    }
    if (data.image_svg) out.innerHTML = data.image_svg;
    else if (data.image_url) { const img = new Image(); img.src = data.image_url; out.appendChild(img); }
    if (data.note) out.innerHTML += '<div class="note">' + escapeHtml(data.note) + "</div>";
  } catch (e) {
    out.innerHTML = '<div class="note">Error: ' + e.message + "</div>";
  }
});

loadMeta();
