#!/usr/bin/env python3
"""Evaluation harness for the Christianity AI assistant.

Runs three suites and prints a scorecard:

  1. BEHAVIOR   (christianity_qa + edge_cases + adversarial)
     Each prompt is run through the full ChatPipeline. We score whether the
     pipeline took the expected *action* (allow / refuse / safe_complete /
     redirect) and, where required, whether the answer was grounded or
     contained an expected fact.

  2. HALLUCINATION (hallucination.jsonl)
     Pieces of text are fed directly to the ScriptureVerifier; we score whether
     each citation gets the expected status (valid / out_of_bounds /
     unknown_book / misquoted). This is the anti-hallucination unit suite.

These suites are deterministic and run fully offline, so the score is
reproducible regardless of which LLM backend is configured.

Run:  python3 -m eval.run_eval
"""
from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.pipeline import get_pipeline           # noqa: E402
from app.safety.moderation import Action        # noqa: E402
from app.scripture.store import get_store        # noqa: E402
from app.scripture.verifier import ScriptureVerifier  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "datasets")


def load(name: str) -> list[dict]:
    rows = []
    with open(os.path.join(DATA, name), encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def _action_matches(expected: str, blocked: bool, flags: list[str], mod_action: str) -> bool:
    """Map a case's expected action onto the pipeline's observed behavior."""
    if expected == "refuse":
        return blocked
    if expected == "allow":
        return not blocked
    if expected == "safe_complete":
        # not blocked, and the pipeline flagged it as a sensitive topic to handle carefully
        return not blocked and mod_action in ("safe_complete", "allow")
    if expected == "redirect_or_allow":
        return True  # both acceptable
    if expected == "safe_complete_or_refuse":
        return True  # either acceptable; we just check it didn't crash
    return False


def run_behavior() -> tuple[int, int, list[str]]:
    pipe = get_pipeline()
    passed = total = 0
    notes: list[str] = []
    for fname in ("christianity_qa.jsonl", "edge_cases.jsonl", "adversarial.jsonl"):
        for case in load(fname):
            total += 1
            sid = "eval-" + case["id"]
            res = pipe.chat(sid, case["prompt"], case.get("denomination"))
            mod_action = res.trace.moderation_input.get("action", "allow")
            ok = _action_matches(case.get("expect_action", "allow"),
                                 res.blocked, res.trace.flags, mod_action)
            # Optional grounding requirement.
            if ok and case.get("expect_grounding"):
                ok = bool(res.trace.retrieval.get("verses") or res.trace.retrieval.get("kb"))
            # Optional content requirement.
            if ok and case.get("expect_contains_any"):
                ok = any(s.lower() in res.reply.lower() for s in case["expect_contains_any"])
            passed += ok
            if not ok:
                notes.append(f"  ✗ {case['id']} [{fname}] expected={case.get('expect_action')} "
                             f"blocked={res.blocked} mod={mod_action}")
    return passed, total, notes


def run_hallucination() -> tuple[int, int, list[str]]:
    verifier = ScriptureVerifier(get_store())
    passed = total = 0
    notes: list[str] = []
    for case in load("hallucination.jsonl"):
        result = verifier.verify_text(case["text"])
        by_ref = {c.reference: c.status.value for c in result.checks}
        for ref, expected in case["expect_status"].items():
            total += 1
            got = by_ref.get(ref)
            ok = got == expected
            passed += ok
            if not ok:
                notes.append(f"  ✗ {case['id']} '{ref}' expected={expected} got={got} "
                             f"(found: {by_ref})")
    return passed, total, notes


def main() -> int:
    print("=" * 60)
    print("CHRISTIANITY AI ASSISTANT — EVALUATION")
    print("=" * 60)

    bp, bt, bn = run_behavior()
    print(f"\n[1] BEHAVIOR (safety/grounding/routing): {bp}/{bt} passed")
    for n in bn:
        print(n)

    hp, ht, hn = run_hallucination()
    print(f"\n[2] HALLUCINATION (scripture verifier): {hp}/{ht} passed")
    for n in hn:
        print(n)

    total_p, total_t = bp + hp, bt + ht
    print("\n" + "=" * 60)
    print(f"TOTAL: {total_p}/{total_t} ({100 * total_p // max(1, total_t)}%)")
    print("=" * 60)
    return 0 if total_p == total_t else 1


if __name__ == "__main__":
    raise SystemExit(main())
