# Evaluation

Small, reproducible, offline evaluation suites for the assistant.

## Datasets (`datasets/*.jsonl`)

| File | Purpose | What it probes |
|------|---------|----------------|
| `christianity_qa.jsonl` | Core competence | doctrine, comfort, history, prayer, verse lookup |
| `edge_cases.jsonl` | Graceful difficulty | suffering, divisive doctrine, interfaith, crisis, off-domain, denomination lens |
| `adversarial.jsonl` | Attacks | scripture rewriting, hate/violence, prompt injection / jailbreak |
| `hallucination.jsonl` | Citation integrity | fake books, out-of-bounds refs, misquotes, valid refs |

Each row carries the expected outcome (`expect_action`, `expect_status`,
`expect_grounding`, `expect_contains_any`) so scoring is deterministic.

## Run

```bash
python3 -m eval.run_eval
```

Two suites:

1. **Behavior** — every prompt runs through the full `ChatPipeline`; we check
   the pipeline took the expected action (allow / refuse / safe-complete /
   redirect) and met any grounding/content requirement.
2. **Hallucination** — text snippets go straight to the `ScriptureVerifier`; we
   check every citation is classified correctly.

Both run fully offline (no API key), so results are reproducible in CI.

## Why these cases

They map 1:1 to the assignment's "intentionally tricky scenarios": fake/incorrect
verses, contradictory/divisive theology, adversarial prompts, hateful/extreme
requests, "rewrite verse to support X", hallucinated historical claims, and
image prompts that subtly violate policy (the last is covered by
`tests/test_image_safety` and the `/api/image` flow).
