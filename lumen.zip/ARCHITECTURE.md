# Architecture note

## 1. The core problem and the key bet

The brief is not "a chatbot." Its hardest requirements are **grounding**,
**hallucination prevention**, and **safety** in a domain where getting a quote
wrong is a serious failure (a fabricated Bible verse presented as real is worse
than "I don't know").

**Key architectural bet:** treat the LLM as *untrusted* for facts. Wrap it in a
pipeline that (a) feeds it verified context and (b) **independently verifies
every scripture citation it emits against a ground-truth corpus.** This converts
hallucinated scripture from an invisible risk into a detectable, flaggable
event — regardless of which model (or no model) generates the text.

## 2. Pipeline

```
user message
  │
  ▼
[1] INPUT MODERATION ── refuse (hate / violence / self-harm / scripture-rewrite /
  │                     injection) · or flag SAFE_COMPLETE for divisive topics
  ▼
[2] MEMORY ─────────── session history + denomination lens + running summary
  │
  ▼
[3] RETRIEVAL (RAG) ── top verses (full-Bible TF-IDF) + vetted KB entries
  │
  ▼
[4] GENERATION ─────── provider (Anthropic / OpenAI / offline-grounded) with a
  │                     layered system prompt + grounding context
  ▼
[5] SCRIPTURE VERIFY ─ extract every citation → validate book/chapter/verse vs
  │                     canon → compare quoted wording vs KJV → annotate/flag
  ▼
[6] OUTPUT MODERATION ─ last-mile safety check on generated text
  │
  ▼
[7] PERSIST ────────── store turn; return reply + full decision trace
```

Each stage is a small, independently testable module. The pipeline returns a
**trace** of every decision, which the UI renders — transparency is a feature,
and it's also what the eval harness asserts against.

## 3. Grounding & hallucination prevention (the centerpiece)

`app/scripture/` is a three-part grounding subsystem over a **verified KJV
corpus** (66 books, ~31k verses, downloaded and integrity-checked by
`scripts/build_corpus.py` — we rejected a popular dataset that had corrupted
Genesis 1:1).

- **`canon.py`** — canonical structure + a tolerant reference parser/alias map
  ("Jhn 3:16", "1 Cor 13:4-7", "Ps 23"). First line of defense: a book that
  doesn't exist (`Hezekiah`) or a verse out of range (`John 3:99`) is caught
  structurally, no text needed.
- **`store.py`** — the single source of truth for verse text + an offline
  TF-IDF search for topical retrieval (so "what does the Bible say about
  anxiety?" pulls *real* verses).
- **`verifier.py`** — classifies every citation in any text as
  `VALID / OUT_OF_BOUNDS / UNKNOWN_BOOK / MISQUOTED`. If a quotation accompanies
  a reference, it's compared to the KJV via sequence similarity, so a real
  reference with invented wording (a paraphrase passed off as a direct quote) is
  caught as `MISQUOTED`.

Because the offline responder *only* emits verses drawn from the store, it
cannot hallucinate scripture by construction; for hosted LLMs the verifier is
the safety net, and the system prompt tells the model its citations will be
checked.

Non-scripture facts (councils, creeds, dates, denominational positions) are
grounded by a curated `rag/knowledge_base.py` so the model doesn't invent
history.

## 4. Safety (defense in depth)

`app/safety/` runs **before** generation (decide whether to call the model) and
**after** (catch a model that was talked into something), plus a dedicated
**image-prompt** screen. Detection is rule-based on purpose: transparent,
deterministic, testable, offline. An `external_hook` seam is provided to add a
hosted moderation model in production.

A deliberate product decision: legitimately *hard* questions (suffering, hell,
predestination, other religions) are **not refused**. They take a
`SAFE_COMPLETE` path that injects guidance to answer with balance, humility, and
fair representation of traditions. Hard refusal is reserved for genuine harm
(hate, violence, self-harm, scripture manipulation, jailbreaks). Refusing honest
theology would make the product pastorally cold and useless.

## 5. Prompt engineering

`app/prompts.py` assembles the system prompt from composable blocks —
IDENTITY · GROUNDING · SAFETY · HUMILITY · DENOMINATION · TONE/MEMORY — rather
than one opaque string. This keeps tone consistent across turns and lets each
guardrail be tuned and reasoned about in isolation.

## 6. Denomination awareness

`app/denomination/` defines lenses (Ecumenical default, Catholic, Orthodox,
Protestant) that shape emphasis, authorities, and tone, and surface honest notes
(e.g. deuterocanon not in the verifier). Default leads with shared creedal
consensus, then notes differences — it doesn't silently pick a side.

## 7. Multimodal image workflow

`app/image/generator.py` is a workflow: **safety screen → reframe → theme-aware
enrichment → provider → offline SVG fallback**. The reframe step handles "subtle
policy violations" (e.g. depicting God the Father → steer to symbolic light/dove;
depicting Muhammad → declined respectfully) *before* any API spend, and the SVG
fallback makes the multimodal flow fully demonstrable with no key.

## 8. Provider abstraction & offline-first

`app/llm/` defines one `LLMProvider` interface with Anthropic, OpenAI, and an
**offline grounded responder** behind it; `factory.py` auto-selects based on
available keys and always falls back to offline. This is why the demo runs
anywhere, and why the grounding/safety guarantees hold across every backend.

## 9. What I'd add next

Dense-embedding retrieval + a vector DB behind the existing `Retriever`
interface; an LLM-as-judge eval tier on top of the deterministic suites;
deuterocanon for Catholic/Orthodox accuracy; cross-reference expansion; and a
hosted moderation model wired into `external_hook`.
