#!/usr/bin/env bash
# Start the Christianity AI assistant.
#   - Runs fully offline by default (no API key required).
#   - Set ANTHROPIC_API_KEY or OPENAI_API_KEY to enable a hosted LLM / images.
set -euo pipefail

cd "$(dirname "$0")"

# Rebuild the verified KJV corpus if it's missing (needs network once).
if [ ! -f app/scripture/data/kjv.json ]; then
  echo "Scripture corpus missing — building it (one-time, needs network)…"
  python3 scripts/build_corpus.py
fi

PORT="${PORT:-8000}"
echo "Starting on http://localhost:${PORT}  (LLM mode chosen automatically)"
exec python3 -m uvicorn app.main:app --host 0.0.0.0 --port "${PORT}"
