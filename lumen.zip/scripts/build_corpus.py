#!/usr/bin/env python3
"""Build a normalized, verified KJV scripture corpus for grounding.

Source: aruljohn/Bible-kjv (public-domain King James Version, per-book JSON).

Why this matters for the assignment
------------------------------------
Scripture grounding and hallucination prevention are only as trustworthy as the
underlying text. We deliberately *verify* the source instead of trusting the
first dataset we found: an earlier candidate (thiagobodruk/bible) silently
corrupted Genesis 1:1 ("In the first chapter is the beginning ...").  This
script downloads an authoritative source, normalizes it into a single corpus,
and prints sanity checks so the data backing every citation is auditable.

Output: app/scripture/data/kjv.json
    {
      "translation": "KJV",
      "books": [
        {"name": "Genesis", "order": 1, "chapters": [["v1", "v2", ...], ...]},
        ...
      ]
    }

Run:  python3 scripts/build_corpus.py
Network is only needed at build time; the app runs fully offline afterwards.
"""
from __future__ import annotations

import json
import os
import sys
import time
import urllib.request

RAW = "https://raw.githubusercontent.com/aruljohn/Bible-kjv/master"
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "scripture", "data", "kjv.json")

SANITY = {
    ("Genesis", 1, 1): "In the beginning God created the heaven and the earth.",
    ("John", 3, 16): "For God so loved the world",
    ("Psalms", 23, 1): "The LORD is my shepherd",
}


def fetch_json(url: str, retries: int = 4):
    last = None
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(url, timeout=40) as r:
                return json.loads(r.read().decode("utf-8-sig"))
        except Exception as e:  # noqa: BLE001 - build-time best effort
            last = e
            time.sleep(2 ** attempt)
    raise RuntimeError(f"failed to fetch {url}: {last}")


def main() -> int:
    books_list = fetch_json(f"{RAW}/Books.json")
    print(f"Canonical books: {len(books_list)}", flush=True)

    corpus = {"translation": "KJV", "books": []}
    total_verses = 0
    for order, name in enumerate(books_list, start=1):
        fname = name.replace(" ", "")  # aruljohn convention: "1 Samuel" -> 1Samuel.json
        data = fetch_json(f"{RAW}/{fname}.json")
        chapters = []
        for ch in data["chapters"]:
            verses = [v["text"].strip() for v in ch["verses"]]
            chapters.append(verses)
            total_verses += len(verses)
        corpus["books"].append({"name": name, "order": order, "chapters": chapters})
        print(f"  [{order:2}] {name:18} chapters={len(chapters)}", flush=True)

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(corpus, f, ensure_ascii=False)
    print(f"\nWrote {OUT}  books={len(corpus['books'])} verses={total_verses} "
          f"size={os.path.getsize(OUT)//1024}KB", flush=True)

    by_name = {b["name"]: b for b in corpus["books"]}
    ok = True
    for (bk, ch, vs), expect in SANITY.items():
        try:
            text = by_name[bk]["chapters"][ch - 1][vs - 1]
        except Exception:  # noqa: BLE001
            text = "<missing>"
        passed = text.startswith(expect)
        ok = ok and passed
        print(f"CHECK {bk} {ch}:{vs} -> {'OK' if passed else 'FAIL'} :: {text[:60]}")
    if not ok:
        print("Integrity check FAILED", file=sys.stderr)
        return 1
    print("All integrity checks passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
