# Lumen — a grounded, safe Christianity AI assistant

Lumen answers Christianity-related questions, generates Christian content
(prayers, devotionals, reflections), and runs a safe Christian image-generation
flow. Its defining feature is **grounding**: every Bible verse it cites is
checked against a verified King James corpus, so fabricated or misquoted
scripture is caught and flagged rather than passed off as truth.

> Built to demonstrate prompt engineering, grounding strategy, hallucination
> handling, AI-safety thinking, multimodal workflow, and architecture — not UI
> polish. **It runs with zero API keys.**

---

## Quickstart

```bash
pip install -r requirements.txt          # only fastapi + uvicorn are required
python3 scripts/build_corpus.py          # one-time: download & verify the KJV (needs network)
./run.sh                                  # serves http://localhost:8000
```

Then open the page and try the example chips: a normal question, a verse to
verify, a *fake* verse (`John 3:99`), an adversarial "rewrite a verse" prompt,
and a hard theological question. The right-hand panel shows the live **pipeline
trace** (what each safety/grounding stage decided) and the **image flow**.

No keys needed: Lumen falls back to an **offline grounded responder** that
composes answers only from verified scripture + a vetted knowledge base, and an
**SVG concept-card** for images. Add `ANTHROPIC_API_KEY` or `OPENAI_API_KEY`
(see `.env.example`) to switch on a hosted LLM / real image generation — the
*same* grounding and safety layers wrap the richer output.

## Run the tests & evaluation

```bash
python3 tests/test_scripture.py
python3 tests/test_safety.py
python3 tests/test_pipeline.py
python3 -m eval.run_eval        # behavior + hallucination scorecards
```

## What's implemented (vs. the brief)

| Requirement | Where |
|---|---|
| Chat interface | `app/static/*`, `POST /api/chat` |
| Scripture-aware responses | `app/rag/retriever.py` + `app/prompts.py` |
| Bible verse grounding / citations | `app/scripture/` (store, canon, **verifier**) |
| Christian image generation flow | `app/image/generator.py`, `POST /api/image` |
| Conversation memory | `app/memory/store.py` |
| Moderation / safety layer | `app/safety/` (input + output + image) |
| Denomination-aware handling | `app/denomination/profiles.py` |
| Difficult questions handled gracefully | `SAFE_COMPLETE` path in moderation + `prompts.HUMILITY` |
| Hallucination prevention | **`app/scripture/verifier.py`** (verify every citation) |
| Eval / edge / adversarial / hallucination datasets | `eval/datasets/*.jsonl`, `eval/run_eval.py` |

See **[ARCHITECTURE.md](ARCHITECTURE.md)** for the design rationale and
**[WALKTHROUGH.md](WALKTHROUGH.md)** for the demo script.

## Honest limitations

- Bundled scripture is the **Protestant 66-book KJV**. Catholic/Orthodox
  deuterocanon isn't in the verifier yet; the app says so when relevant.
- Moderation is rule-based (transparent, offline, testable). In production you'd
  add a hosted moderation model behind the provided `external_hook` seam.
- Offline retrieval is pure-Python TF-IDF, not dense embeddings. The interface
  is swappable for an embedding/vector-DB backend.
- The offline responder is grounded but terse by design; a hosted LLM gives the
  fluent experience while keeping the same guardrails.
