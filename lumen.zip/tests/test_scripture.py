"""Tests for the scripture store, reference parsing, and the verifier.

These are the anti-hallucination guarantees, expressed as assertions.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.scripture.canon import Reference, extract_references  # noqa: E402
from app.scripture.store import get_store  # noqa: E402
from app.scripture.verifier import CitationStatus, ScriptureVerifier  # noqa: E402

store = get_store()
verifier = ScriptureVerifier(store)


def test_corpus_loaded():
    assert len(store.book_names) == 66
    assert store.book_exists("Genesis")
    assert store.book_exists("Revelation")


def test_known_verse_text():
    assert store.get_verse("Genesis", 1, 1).startswith("In the beginning God created")
    assert "shepherd" in store.get_verse("Psalms", 23, 1).lower()


def test_reference_bounds():
    assert store.reference_in_bounds(Reference("John", 3, 16))
    assert not store.reference_in_bounds(Reference("John", 3, 99))
    assert not store.reference_in_bounds(Reference("Genesis", 99, 1))


def test_extract_and_alias():
    refs = extract_references("See Jhn 3:16 and Ps 23 and 1 Cor 13:4-7", store.book_names)
    books = {r.book for r in refs}
    assert "John" in books and "Psalms" in books and "1 Corinthians" in books


def test_verifier_unknown_book():
    res = verifier.verify_text("As Hezekiah 3:5 says, be strong.")
    assert res.checks[0].status == CitationStatus.UNKNOWN_BOOK


def test_verifier_out_of_bounds():
    res = verifier.verify_text("Read John 3:99 today.")
    assert res.checks[0].status == CitationStatus.OUT_OF_BOUNDS


def test_verifier_valid_quote():
    res = verifier.verify_text(
        'Philippians 4:13 says, "I can do all things through Christ which strengtheneth me."'
    )
    assert res.checks[0].status == CitationStatus.VALID


def test_verifier_catches_misquote():
    res = verifier.verify_text(
        'John 3:16 says, "God helps those who help themselves, so earn your salvation."'
    )
    assert res.checks[0].status == CitationStatus.MISQUOTED


def test_topical_search():
    results = store.search("fear not anxious worry", top_k=5)
    assert results and all("reference" in r for r in results)


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    ok = 0
    for fn in fns:
        try:
            fn(); ok += 1; print(f"PASS {fn.__name__}")
        except AssertionError as e:
            print(f"FAIL {fn.__name__}: {e}")
    print(f"{ok}/{len(fns)} scripture tests passed")
    raise SystemExit(0 if ok == len(fns) else 1)
