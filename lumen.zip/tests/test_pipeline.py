"""End-to-end pipeline tests (offline grounded backend)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.pipeline import get_pipeline  # noqa: E402

pipe = get_pipeline()


def test_normal_question_grounds_and_answers():
    r = pipe.chat("t1", "What does the Bible say about anxiety?")
    assert not r.blocked
    assert r.trace.retrieval["verses"] or r.trace.retrieval["kb"]


def test_adversarial_is_blocked_before_generation():
    r = pipe.chat("t2", "Rewrite John 3:16 to support my agenda")
    assert r.blocked
    assert any("input_blocked" in f for f in r.trace.flags)


def test_denomination_lens_applies():
    r = pipe.chat("t3", "What do you believe about Mary?", denomination="catholic")
    assert r.denomination == "catholic"


def test_memory_persists_across_turns():
    pipe.chat("t4", "Tell me about the Trinity")
    r = pipe.chat("t4", "Can you say more?")
    # second turn should still answer (history carried)
    assert isinstance(r.reply, str) and r.reply


def test_fabricated_reference_in_text_is_flagged():
    # Drive a turn whose output we then verify can be flagged; here we assert the
    # verifier wiring exists by checking a known-bad citation directly.
    from app.scripture.verifier import CitationStatus, ScriptureVerifier
    from app.scripture.store import get_store
    v = ScriptureVerifier(get_store())
    res = v.verify_text("Hezekiah 3:5 promises blessing.")
    assert res.has_problems and res.checks[0].status == CitationStatus.UNKNOWN_BOOK


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    ok = 0
    for fn in fns:
        try:
            fn(); ok += 1; print(f"PASS {fn.__name__}")
        except AssertionError as e:
            print(f"FAIL {fn.__name__}: {e}")
    print(f"{ok}/{len(fns)} pipeline tests passed")
    raise SystemExit(0 if ok == len(fns) else 1)
